const settings = {
  packname: 'DEV•ZIKKY Bot',
  author: '‎',
  botName: "DEV•ZIKKY BOT",
  botOwner: 'DEV•ZIKKY',
  ownerNumber: '2348103476646', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "A simple 🎖️ yet unique WhatsApp automation bot⚡⚡🥂🚀",
  version: "1.0.0",
  updateZipUrl: "https://github.com/zikky0001-droid/DEV_ZIKKY-MD/archive/refs/heads/main.zip",
};

module.exports = settings;
